<?php
// This file was auto-generated from sdk-root/src/data/mwaa/2020-07-01/paginators-1.json
return [ 'pagination' => [ 'ListEnvironments' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'Environments', ], ],];

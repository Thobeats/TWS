<?php
// This file was auto-generated from sdk-root/src/data/mediapackagev2/2022-12-25/paginators-1.json
return [ 'pagination' => [ 'ListChannelGroups' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'Items', ], 'ListChannels' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'Items', ], 'ListOriginEndpoints' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'Items', ], ],];

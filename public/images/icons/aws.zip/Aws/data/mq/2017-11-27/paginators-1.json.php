<?php
// This file was auto-generated from sdk-root/src/data/mq/2017-11-27/paginators-1.json
return [ 'pagination' => [ 'ListBrokers' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'BrokerSummaries', ], ],];

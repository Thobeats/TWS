<?php
// This file was auto-generated from sdk-root/src/data/arc-zonal-shift/2022-10-30/paginators-1.json
return [ 'pagination' => [ 'ListManagedResources' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'items', ], 'ListZonalShifts' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'items', ], ],];

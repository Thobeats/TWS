<?php
// This file was auto-generated from sdk-root/src/data/sagemaker-edge/2020-09-23/paginators-1.json
return [ 'pagination' => [],];

<?php
// This file was auto-generated from sdk-root/src/data/chime-sdk-media-pipelines/2021-07-15/paginators-1.json
return [ 'pagination' => [ 'ListMediaCapturePipelines' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'ListMediaInsightsPipelineConfigurations' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'ListMediaPipelines' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];

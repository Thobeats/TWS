<?php
// This file was auto-generated from sdk-root/src/data/marketplacecommerceanalytics/2015-07-01/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-east-1', 'testCases' => [ [ 'operationName' => 'GenerateDataSet', 'input' => [ 'dataSetType' => 'fake-type', 'dataSetPublicationDate' => 0, 'roleNameArn' => 'fake-arn', 'destinationS3BucketName' => 'fake-bucket', 'snsTopicArn' => 'fake-arn', ], 'errorExpectedFromService' => true, ], ],];

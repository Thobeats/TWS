# Bootstrap 5 Intro Tour
Extension for bootstrap 5 which allows to build intro tours.

Demo site: <a href="https://iprogramista.pl/Bs5IntroTour">Bootstrap 5 Into Tour free extension</a>

The extension is written in plain JS - so there is no jQuery dependencies.

The plug in allows to make a quick tour about your application to your users/customers. It is very intuitive and customizable. 
Feel free to create an issue on github in cases of any bugs or ideas.

